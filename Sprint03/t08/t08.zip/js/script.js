function createTable() {
  let mainBlock = document.querySelector('main');
  let table = document.createElement('table');
  let status = document.createElement('div');
  
  mainBlock.append(table);
  status.className = 'notification';
  status.innerHTML = 'Sorting by Name, order: ASC';
  mainBlock.append(status);
  return table;
}

function initTable() {
  let heroes = [
    {Name: "Black Panther", Strength: 66, Age: 53},
    {Name: "Captain America", Strength: 79, Age: 137},
    {Name: "Captain Marvel", Strength: 97, Age: 26},
    {Name: "Hulk", Strength: 80, Age: 49},
    {Name: "Iron Man", Strength: 88, Age: 48},
    {Name: "Spider-Man", Strength: 78, Age: 16},
    {Name: "Thanos", Strength: 99, Age: 1000},
    {Name: "Thor", Strength: 95, Age: 1000},
    {Name: "Yon-Rogg", Strength: 73,Age: 52}
  ];
  
  function generateTableHead(table, data) {
    let thead = table.createTHead();
    let row = thead.insertRow();
  
    for (let key of data) {
      let th = document.createElement('th');
      let text = document.createTextNode(key);
  
      th.appendChild(text);
      row.appendChild(th);
    }
  }
  
  function generateTable(table, data) {
    let tbody = document.createElement('tbody');
    
    for (let element of data) {
      let row = tbody.insertRow();
  
      for (key in element) {
        let cell = row.insertCell();
        let text = document.createTextNode(element[key]);
        cell.appendChild(text);
      }
    }
    table.append(tbody);
  }
  
  let data = Object.keys(heroes[0]);

  generateTableHead(table, data);
  generateTable(table, heroes);
}

function initEvents() {
  let headCells = document.querySelectorAll('th');
  
  function sortTableByNum(cell) {
    let sortedRows = Array.from(table.rows).slice(1);
    
    if (isAsc) {
      sortedRows.sort((a, b) =>
        a.cells[cell].innerHTML > b.cells[cell].innerHTML ? 1 : -1);
      isAsc = false;
    }
    else {
      sortedRows.sort((a, b) =>
        b.cells[cell].innerHTML > a.cells[cell].innerHTML ? 1 : -1);
      isAsc = true;
    }
    table.tBodies[0].append(...sortedRows);
  }

  function changeStatus(param, order) {
    let status = document.querySelector('.notification');

    status.innerHTML = `Sorting by ${param}, order: ${order}`;
  }
  

  headCells[0].addEventListener('click', () => {
    sortTableByNum(0);
    changeStatus('Name', isAsc ? 'DSC' : 'ASC');
  });
  headCells[1].addEventListener('click', () => {
    sortTableByNum(1);
    changeStatus('Strength', isAsc ? 'DSC' : 'ASC');
  });
  headCells[2].addEventListener('click', () => {
    sortTableByNum(2);
    changeStatus('Age', isAsc ? 'DSC' : 'ASC');
  });
}

let table = createTable();
let isAsc = true;

initTable();
initEvents();


























// function sortTableByNum(cell) {
//   let sortedRows = Array.from(table.rows).slice(1);
  
//   if (isAsc) {
//     sortedRows.sort((a, b) =>
//       a.cells[cell].innerHTML > b.cells[cell].innerHTML ? 1 : -1);
//     isAsc = false;
//   }
//   else {
//     sortedRows.sort((a, b) =>
//       b.cells[cell].innerHTML > a.cells[cell].innerHTML ? 1 : -1);
//     isAsc = true;
//   }
//   table.tBodies[0].append(...sortedRows);
// }